package com.capgemini.tcc.service;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;

public interface IPatientService {

	public int  AddPatientInfo(PatientBean patient) throws PatientException;
	
	public PatientBean SearchByPatientId(int patientId) throws PatientException;
	
	public boolean ValidateName(String name) throws PatientException;
	
	public boolean ValidateAge(int age) throws PatientException;
	
	public boolean ValidatePhone(String phone) throws PatientException;
	
	public boolean validatePatientId(int patientId );
}
