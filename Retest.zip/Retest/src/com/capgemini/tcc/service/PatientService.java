package com.capgemini.tcc.service;

import java.util.regex.Pattern;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.IPatientDAO;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exception.PatientException;

public class PatientService implements IPatientService{
IPatientDAO dao=new PatientDAO();

public void setDao(IPatientDAO dao)
{
	this.dao = dao;
}

//------------------------ TakeCare Clinic Software Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addPatientInformation
	 - Input Parameters	:	patient object
	 - Return Type		:	patientId
	 - Throws			:  	PatientException
	 - Author			:	ADM-IG-HWDLAB1D
	 - Creation Date	:	06/12/2019
	 - Description		:	adding patient to database calls dao method AddPatientInfo(PatientBean patient)
	 ********************************************************************************************************/

	@Override
	public int AddPatientInfo(PatientBean patient) throws PatientException {
		
		return dao.AddPatientInfo(patient);
	}

	
	//------------------------ TakeCare Clinic Software Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	viewPatientDetails
		 - Input Parameters	:	patientId
		 - Return Type		:	patient object
		 - Throws		    :  	PatientException
		 - Author		    :	ADM-IG-HWDLAB1D
		 - Creation Date	:	06/12/2019
		 - Description		:	calls dao method SearchByPatientId(int patientId)
		 ********************************************************************************************************/

	
	@Override
	public PatientBean SearchByPatientId(int patientId) throws PatientException {
		
		return dao.SearchByPatientId(patientId);
	}

	//------------------------ TakeCare Clinic Software Application --------------------------
		/*******************************************************************************************************
		 - Function Name	: ValidateName(String name)
		 - Input Parameters	: PatientBean bean
		 - Return Type		: void
		 - Throws		    : PatientException
		 - Author	      	: ADM-IG-HWDLAB1D
		 - Creation Date	: 06/12/2019
		 - Description		: validates the DonorBean object
		 ********************************************************************************************************/

	@Override
	public boolean ValidateName(String name) throws PatientException {
		if(Pattern.matches("^[A-Z]{1}[a-z]{3,15}$", name))
			
			return true;
		else
			return false;
	}

	@Override
	public boolean ValidateAge(int age) throws PatientException {
		
		String pattern="[0-9]{1,3}";
		if(Pattern.matches(pattern, age+""))
			return true;
		else
		return false;
	}

	
	@Override
	public boolean ValidatePhone(String phone) throws PatientException {
    if(Pattern.matches("^[7-9]{1}[0-9]{9}$", phone))
			
			return true;
		else
			return false;
	}

	@Override
	public boolean validatePatientId(int patientId) {
		if(Pattern.matches("^[0-9]{3}$", patientId+""))
			
			return true;
		else
			return false;
	
		
	}

}
