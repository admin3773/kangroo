package com.capgemini.tcc.test;

import static org.junit.Assert.*;

import java.sql.Connection;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.IPatientDAO;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.service.PatientService;

public class DAOTests {
 PatientService service;
 IPatientDAO dao;
	
	
	@Before
	public void initialize() {
		dao=new PatientDAO();
		service=new PatientService();
		service.setDao(dao);

	}
	@Test
	public void testSearchPatientById() throws PatientException {
		PatientBean id=service.SearchByPatientId(1005);
		assertNotSame(id, 0);
	}
	
	@Test
	
	public void testAddPatientDetails() throws PatientException {
		
		PatientBean patient=new PatientBean();
		patient.setPatientName("Rajesh");
		patient.setAge(30);
		patient.setPhone("9890232306");
		patient.setDescription("Suffering from cough");
		
		int id=service.AddPatientInfo(patient);
		assertNotNull(patient);

	}
	
	
	
	
	@Test
	public void TestDBUtil() {
		Connection connection=com.capgemini.tcc.util.DBUtil.getConnection();
		assertNotNull(connection);
	}
	

	@After
	public void destroy() {
		dao=null;
		service=null;

	}
}
