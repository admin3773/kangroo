package com.capgemini.tcc.ui;

import java.security.Provider.Service;
import java.util.Scanner;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.service.IPatientService;
import com.capgemini.tcc.service.PatientService;

public class Client {

	public static void main(String[] args) {
		IPatientService service=new PatientService();
		Scanner scanner = new Scanner(System.in);
		System.out.println("WELCOME TO TAKECARE CLINIC");
		System.out.println("---------------------------------------------");
		do {
			System.out.println("1. Add Patient Information ");
			System.out.println("2. Search Patient by Id ");
			System.out.println("3. Exit");
			System.out.println("------------------------------------------");
			System.out.println("Please select operation to perform");

			int choice = scanner.nextInt();
			switch (choice) {
			case 1:

				System.out.println("Enter the name of the Patient: ");
				String name=scanner.next();
				try {
					if(service.ValidateName(name)==false){
						System.err.println("Enter correct name");
						break;
					}
				} catch (PatientException e1) {
					System.out.println(e1.getMessage());
				}
				
				System.out.println("Enter Patient Age: ");
				int age=scanner.nextInt();
				try {
					if(service.ValidateAge(age)==false){
						System.err.println("Enter valid Age");
						break;
					}
				} catch (PatientException e1) {
					System.out.println(e1.getMessage());
				}
				
				System.out.println("Enter Patient Phone number: ");
				String phone=scanner.next();
				try {
					if(service.ValidatePhone(phone)==false){
						System.err.println("Enter Numbers only");
						break;
					}
				} catch (PatientException e1) {
					System.out.println(e1.getMessage());
				}
				
				System.out.println("Enter Description: ");
				scanner.nextLine();
			    String desc=scanner.nextLine();
			   
				
			    PatientBean patient=new PatientBean(name,age,phone,desc);
			    
			    int patientId;
			    try {
					patientId=service.AddPatientInfo(patient);
					System.out.println("Patient Information stored successfully for "+patientId);
				} catch (PatientException e) {
					System.out.println("Data not inserted");
				}
			   
				break;

			case 2:


				System.out.println("Enter Id to search the Patient:");
				int patientId1=scanner.nextInt();
				
				try {
					PatientBean patient1=service.SearchByPatientId(patientId1);
					System.out.println(patient1);
				} catch (PatientException e) {
					System.out.println("Problem occured while searching");
				}
				break;

			case 3:

				System.exit(0);
				
				break;

			default:
				System.out.println("Please enter correct choice");
				break;
			}
		} while (true);

	}
}
