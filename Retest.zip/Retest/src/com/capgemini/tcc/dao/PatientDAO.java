package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import oracle.jdbc.proxy.annotation.Pre;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.logger.MyLogger;
import com.capgemini.tcc.util.DBUtil;

public class PatientDAO implements IPatientDAO{

	Connection Connection=null;
	Logger logger=MyLogger.getLogger();
	public int generatePatientId() throws PatientException {
		logger.info("In generate PatientId");
		Connection=DBUtil.getConnection();
		int patientId=0;
		
		String SQL="Select patient_Id_Seq.nextval from dual";
		
		try {
			Statement statement=Connection.createStatement();
			ResultSet resultSet=statement.executeQuery(SQL);
			resultSet.next();
			patientId=resultSet.getInt(1);
			logger.info("Got Patient with patientId "+patientId);
		} catch (SQLException e) {
			logger.info("error"+e.getMessage());
			throw new PatientException("Problem while generating PatientId\t");
		}
		
		logger.info("Completed getPatientId");
		return patientId;
	}
	
	

	//------------------------ TakeCare Clinic Software Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	AddPatientInfo(PatientBean patient)
	 - Input Parameters	:	PatientBean patient
	 - Return Type		:	patientId
	 - Throws			:   PatientException
	 - Author			:	ADM-IG-HWDLAB1D
	 - Creation Date	:	06/12/2019
	 - Description		:	Adding Patient Details
	 ********************************************************************************************************/
	@Override
	public int AddPatientInfo(PatientBean patient) throws PatientException {
		logger.info("In Add Patient");
		 Connection=DBUtil.getConnection();
		 logger.info("input is"+patient);
		 int patientId=generatePatientId();
		 
		 String SQL="insert into Patient values(?,?,?,?,?,sysdate)";
		 
		 try {
			PreparedStatement preparedStatement=Connection.prepareStatement(SQL);
			preparedStatement.setInt(1, patientId);
			preparedStatement.setString(2, patient.getPatientName());
			preparedStatement.setInt(3, patient.getAge());
			preparedStatement.setString(4, patient.getPhone());
			preparedStatement.setString(5, patient.getDescription());
			preparedStatement.executeUpdate();
			
		} catch (SQLException e) {
			logger.error("error in insert = "+e.getMessage());
			throw new PatientException("Error while inserting Data");
			
		}
		 
		return patientId;
	}
	
	//------------------------ TakeCare Clinic Software Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	SearchByPatientId(int patientId)
		 - Input Parameters	:	patientId
		 - Return Type		:	patient
		 - Throws			:  	PatientException
		 - Author			:	ADM-IG-HWDLAB1D
		 - Creation Date	:	06/12/2019
		 - Description		:	View Patient Details
		 ********************************************************************************************************/

	@Override
	public PatientBean SearchByPatientId(int patientId) throws PatientException {
		Connection=DBUtil.getConnection();
		PatientBean patient=new PatientBean();
		
		String SQL="Select patient_name, age, phone, description, consulation_date from patient where patient_Id=?";
		
		try {
			PreparedStatement preparedStatement=Connection.prepareStatement(SQL);
			preparedStatement.setInt(1, patientId);
			ResultSet resultSet=preparedStatement.executeQuery();
			
			while(resultSet.next()){
				patient.setPatientName(resultSet.getString(1));
				patient.setAge(resultSet.getInt(2));
				patient.setPhone(resultSet.getString(3));
				patient.setDescription(resultSet.getString(4));
				patient.setConsulationDate(resultSet.getDate(5));
				
			}
			
		} catch (SQLException e) {
			throw new PatientException("Problem while fetching data");
		}
		
		return patient;
	}

}
