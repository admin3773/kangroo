package com.capgemini.tcc.bean;

import java.sql.Date;
import java.time.LocalDate;

/**
 * 
 * @author ADM-IG-HWDLAB1D
 *
 */
public class PatientBean {

	int patientId;
	String patientName;
	int age;
	String phone;
	String description;
	Date consulationDate;
	
	public PatientBean() {
		
	}

	/**
	 * 
	 * @param patientName
	 * @param age
	 * @param phone
	 * @param description
	 */
	public PatientBean(String patientName, int age, String phone,
			String description) {
		super();
		this.patientName = patientName;
		this.age = age;
		this.phone = phone;
		this.description = description;
	}

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getConsulationDate() {
		return consulationDate;
	}

	public void setConsulationDate(Date consulationDate) {
		this.consulationDate = consulationDate;
	}

	@Override
	public String toString() {
		return "PatientBean [patientId=" + patientId + ", patientName="
				+ patientName + ", age=" + age + ", phone=" + phone
				+ ", description=" + description + ", consulationDate="
				+ consulationDate + "]";
	}

	

	
	
	
}
