package com.capgemini.tcc.exception;

public class PatientException extends Exception {

	String message;

	public PatientException (String message) {
		this.message = message;
	}

	@Override
	public String getMessage() {
		return this.message;
	}

}
